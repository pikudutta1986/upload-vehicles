<?php
return array(
	'jquery' => '>=1.8.2',
	'jquery_ui' => '>=1.9.1',
	'validate' => '>=1.10.0',
);
?>