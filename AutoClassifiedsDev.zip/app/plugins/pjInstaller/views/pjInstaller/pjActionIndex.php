<?php
include_once pjObject::getConstant('pjInstaller', 'PLUGIN_VIEWS_PATH') . 'pjInstaller/pjActionStep0.php';
?>