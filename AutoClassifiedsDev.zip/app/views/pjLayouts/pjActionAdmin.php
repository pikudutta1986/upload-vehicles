<?php
include(PJ_INSTALL_PATH . PJ_TEMPLATE_PATH . PJ_TEMPLATE_SCRIPT_PATH . "admin/pjActionAdmin.php");
?>